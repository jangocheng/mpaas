---
name: Bug report
about: Create a bug report
---

<!-- ⚠️ Please search existing issues to avoid creating duplicates. ⚠️ -->
<!-- Describe the bug here. -->

## Details
- Browser and browser version: 
- OS version: 
- xterm.js version: 

### Steps to reproduce

1. 
2. 
